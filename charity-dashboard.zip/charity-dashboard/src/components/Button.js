const Button=()=>{
    return(
        <div className="button-container">
                 <a href="https://www.globalgiving.org/"><div className="button">Donate Now</div></a>
        </div>
    );
}
export default Button

// change props and add hoverstates
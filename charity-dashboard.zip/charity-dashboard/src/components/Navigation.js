const Navigation=()=>{
    return(
        <div className="nav">
            <div className="SMlogo">
            </div>
        </div>
    );
}
export default Navigation